# A very simple test file to show
# in github actions module installed


vect= [1, 7, 9]
